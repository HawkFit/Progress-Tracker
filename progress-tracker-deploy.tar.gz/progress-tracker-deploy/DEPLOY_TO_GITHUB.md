# Deploy HawkFit Progress Tracker to GitHub Pages

Follow these steps to get your app live in 2 minutes.

## Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Fill in:
   - **Repository name:** `progress-tracker`
   - **Description:** "HawkFit fitness progress tracker with charts and photos"
   - **Visibility:** Public
   - **Initialize repo:** Leave unchecked (we'll push existing code)
3. Click **Create repository**

## Step 2: Push Code to GitHub

Open your terminal and run these commands:

```bash
cd path/to/progress-tracker-deploy

git config --global user.email "steve@thehawkfit.com"
git config --global user.name "Steve Hawk"

git init
git add .
git commit -m "Initial commit: HawkFit progress tracker"
git branch -M main

git remote add origin https://github.com/YOUR_USERNAME/progress-tracker.git
git push -u origin main
```

**Replace `YOUR_USERNAME` with your GitHub username!**

You'll be prompted for credentials:
- **Username:** Your GitHub username
- **Password:** Paste your PAT token

## Step 3: Enable GitHub Pages

1. Go to your repo → **Settings** (top menu)
2. Scroll to **Pages** (left sidebar)
3. Should auto-detect `gh-pages` branch (created by workflow)
4. Click **Save** if needed

**Your app is live at:** `https://YOUR_USERNAME.github.io/progress-tracker/`

## Step 4: Load Your Data

1. Open the live URL on your phone or computer
2. Go to your coaching sheet → **File → Share → Publish to web → CSV**
3. Copy the published link
4. In the app, paste it in the **Load Data** field
5. Click **Load Data**

Charts appear instantly! 📊

## Troubleshooting

**"Remote origin already exists"**
```bash
git remote set-url origin https://github.com/YOUR_USERNAME/progress-tracker.git
```

**"Nothing to commit"**
Make sure you ran `git add .` in the right directory.

**"App not deploying"**
Check the **Actions** tab in your GitHub repo - workflow should show a green checkmark.

---

Questions? See SETUP_GUIDE.md for detailed photo & Supabase setup.
