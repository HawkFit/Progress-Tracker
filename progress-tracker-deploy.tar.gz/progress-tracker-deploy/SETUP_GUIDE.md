# Complete Setup Guide - HawkFit Progress Tracker

Follow these steps to get your progress tracker running with charts and photos.

## Phase 1: Prepare Your Coaching Data

### Add Body Fat % Column to Your Sheet

1. Open your "Steve Hawks Fasted Weight Sheet" in Google Sheets
2. Insert a new column after "Weight" (column G)
3. Name it "Body Fat %"
4. Add your body fat measurements as you track them

**Why?** The app will automatically chart this data if available.

---

## Phase 2: Deploy the App

### Step 1: Get Your GitHub Token

1. Go to https://github.com/settings/tokens?type=fine-grained
2. Click **Generate new token (fine-grained)**
3. Token name: `progress-tracker-deploy`
4. Expiration: 90 days
5. Repository access: **Only select repositories** → select a new repo you'll create
6. Permissions:
   - Repository permissions → Contents: **Read and write**
7. Click **Generate token**
8. **Copy the token** (you'll use it once, save it safely)

### Step 2: Create a GitHub Repository

1. Go to https://github.com/new
2. Repository name: `progress-tracker` (or similar)
3. Description: "Fitness progress tracker with charts and photos"
4. Choose **Public** (so GitHub Pages can serve it)
5. Click **Create repository**

### Step 3: Push Code to GitHub

Ask Claude to push the code using your token. He'll:
- Clone the repo
- Add all files
- Commit and push to `main` branch
- Enable GitHub Pages in Settings
- Provide you the live URL

### Step 4: Enable GitHub Pages

GitHub Actions will auto-deploy on every push, but verify:

1. Go to your repo → **Settings**
2. Scroll to **Pages**
3. Source: Should be **gh-pages branch** (auto-created)
4. Domain: `https://username.github.io/progress-tracker/`

**Your app is now live!** 🚀

---

## Phase 3: Connect Your Data

### Publish Your Google Sheet as CSV

1. Open your coaching sheet in Google Sheets
2. Go to **File → Share → Publish to web**
3. Format: **CSV**
4. Copy the link
5. In the app, go to **Load Data** field and paste it
6. Click **Load Data**

**Charts will populate automatically!**

### Enable Photo Uploads (Optional)

#### Create a Supabase Project

1. Go to https://supabase.com
2. Sign up (free tier is plenty)
3. Create a new project
4. Wait for it to initialize

#### Get Your Credentials

1. In Supabase, go to **Settings → API**
2. Copy:
   - **Project URL** (e.g., `https://xxx.supabase.co`)
   - **Anon Key** (starts with `eyJ...`)
3. In the app, go to **⚙️ Settings**
4. Paste URL and Key
5. Click **Save Config**

#### Create Storage Bucket

1. In Supabase, go to **Storage** (left sidebar)
2. Click **New bucket**
3. Name: `progress_photos`
4. Uncheck "Private bucket" → make it **Public**
5. Click **Create bucket**

#### Set Upload Policy

1. Go to **SQL Editor** in Supabase
2. Click **New query**
3. Paste this:

```sql
CREATE POLICY "Allow public uploads" 
ON storage.objects 
FOR INSERT 
TO anon 
WITH CHECK (bucket_id = 'progress_photos');
```

4. Click **Run**

**Photos enabled!** 📸

---

## Phase 4: Use the App

### Load Your Data

1. Open the app URL on your computer
2. Paste your published Google Sheet CSV link
3. Click **Load Data**
4. Charts appear instantly!

### Upload Progress Photos

1. Go to **📸 Photos** tab
2. Click **📸 Upload Photo**
3. Select a photo from your phone/computer
4. It's stored with today's date

### Install on Phone

1. Open the app URL in your phone browser
2. Tap **Share** (iOS) or **⋯** menu (Android)
3. Tap **Add to Home Screen**
4. Name it "HawkFit" (or your preference)
5. Tap **Add**

**It's now a full-screen app on your home screen!** 📱

---

## Keeping Data Fresh

The app pulls live data from your Google Sheet every time you load it. Just update your sheet like you normally would, and the charts update automatically.

---

## Troubleshooting

### "CSV link not found"
- Make sure you published the sheet (File → Share → Publish to web)
- Paste the full link including `?format=csv`
- Try pasting the link into your browser to confirm it downloads

### "Photos not uploading"
- Verify Supabase URL and Key are correct (Settings tab)
- Make sure the `progress_photos` bucket is PUBLIC
- Check that the SQL policy was created

### "App not loading on phone"
- Make sure you're adding the correct GitHub Pages URL to home screen
- Clear browser cache if it shows an old version
- Refresh the page after making changes to your sheet

---

## Next Steps

1. ✅ Deploy app to GitHub Pages (Claude handles this)
2. ✅ Publish your coaching sheet as CSV
3. ✅ Load data in the app
4. ✅ Set up Supabase for photos
5. ✅ Install on your phone

Enjoy tracking your progress! 💪
