# HawkFit Progress Tracker

A web app to track fitness progress with charts and progress photos.

## Features

- 📊 **Live Charts**: Weight, body fat %, and macro breakdown from your Google Sheet
- 📸 **Progress Photos**: Upload and track photos with dates (requires Supabase)
- 📱 **Mobile App**: Install on home screen like a native app
- 🔄 **Live Sync**: Real-time updates from your Google Sheet

## Setup

### 1. Publish Your Google Sheet as CSV

1. Open your coaching sheet in Google Sheets
2. Go to **File → Share → Publish to web**
3. Select the sheet tab and choose **CSV** format
4. Copy the published link
5. In the app, paste it in the "Load Data" field

**Example link format:**
```
https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv&gid={SHEET_GID}
```

### 2. Set Up Supabase (Optional - for photo uploads)

1. Create a free account at [supabase.com](https://supabase.com)
2. Create a new project
3. Go to **Settings → API** and copy:
   - Project URL
   - Anon Key
4. In the app Settings tab, paste these credentials
5. In Supabase, create a storage bucket named `progress_photos`
6. Set bucket to public with this policy:
   ```sql
   CREATE POLICY "Allow public uploads" ON storage.objects
   FOR INSERT TO anon 
   WITH CHECK (bucket_id = 'progress_photos');
   ```

### 3. Install on Phone

1. Open the app URL in your phone browser
2. Tap **Share** (iOS) or menu (Android)
3. Select **Add to Home Screen**
4. Tap the new icon to open full-screen like an app

## Development

```bash
npm install
npm run dev    # Start dev server
npm run build  # Build for production
```

## Deployment

Deploy to GitHub Pages:

1. Create GitHub repo
2. Push this code
3. Enable GitHub Pages in Settings
4. Set base URL in `vite.config.js`

## Data Format

Your Google Sheet should have these columns (at minimum):
- `Date` - Entry date
- `Weight` - Weight in lbs
- `Body Fat %` - Optional body fat percentage
- `Protein` - Daily protein intake (g)
- `Carbs` - Daily carbs (g)
- `Fat` - Daily fat (g)

## Privacy

- Data stays in your Google Sheet (not stored by this app)
- Photos are stored in your Supabase account
- No tracking or analytics
