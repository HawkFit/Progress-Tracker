import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, BarChart, Bar,
} from 'recharts';

export default function Charts({ data, loading }) {
  if (loading) return <p>Loading chart data...</p>;
  if (!data || data.length === 0) return <p>No data yet. Load your Google Sheet to see charts.</p>;

  const chartData = data.map(d => ({
    date: d.date,
    weight: d.weight,
    bodyFat: d.bodyFat,
    protein: d.protein,
    carbs: d.carbs,
    fat: d.fat,
  }));

  const commonProps = {
    width: '100%',
    height: 300,
    margin: { top: 5, right: 30, left: 0, bottom: 5 },
  };

  return (
    <div className="charts">
      <div className="chart-container">
        <h3>Weight Progress</h3>
        <ResponsiveContainer {...commonProps}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={['dataMin - 2', 'dataMax + 2']} />
            <Tooltip />
            <Line type="monotone" dataKey="weight" stroke="#2f4a3c" dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {data.some(d => d.bodyFat) && (
        <div className="chart-container">
          <h3>Body Fat % Progress</h3>
          <ResponsiveContainer {...commonProps}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="bodyFat" stroke="#f7971e" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="chart-container">
        <h3>Macro Breakdown (Average)</h3>
        <ResponsiveContainer width="100%" height={300} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <BarChart data={chartData.slice(-30)}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="protein" fill="#d4a574" name="Protein (g)" />
            <Bar dataKey="carbs" fill="#8ba888" name="Carbs (g)" />
            <Bar dataKey="fat" fill="#f7971e" name="Fat (g)" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <style>{`
        .charts { display: flex; flex-direction: column; gap: 2rem; }
        .chart-container { border: 1px solid #e0e0e0; padding: 1rem; border-radius: 8px; }
        .chart-container h3 { margin-bottom: 1rem; color: #2f4a3c; }
        @media (max-width: 768px) {
          .chart-container { padding: 0.5rem; }
        }
      `}</style>
    </div>
  );
}
