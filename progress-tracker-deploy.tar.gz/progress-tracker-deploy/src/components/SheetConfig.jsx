import { useState } from 'react';

export default function SheetConfig({ sheetUrl, onFetch, loading, error }) {
  const [input, setInput] = useState(sheetUrl);

  const handleFetch = () => {
    onFetch(input);
  };

  return (
    <div className="sheet-config">
      <input
        type="text"
        placeholder="Paste Google Sheet CSV export URL..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && handleFetch()}
      />
      <button onClick={handleFetch} disabled={loading}>
        {loading ? 'Loading...' : 'Load Data'}
      </button>
      {error && <div className="error">{error}</div>}
    </div>
  );
}
