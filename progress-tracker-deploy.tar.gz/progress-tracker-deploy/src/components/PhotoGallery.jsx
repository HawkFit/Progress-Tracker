import { useState, useRef } from 'react';
import { createClient } from '@supabase/supabase-js';

export default function PhotoGallery({ supabaseConfig, onConfigChange }) {
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef(null);

  const supabase = supabaseConfig.url && supabaseConfig.key 
    ? createClient(supabaseConfig.url, supabaseConfig.key)
    : null;

  const handleUpload = async (file) => {
    if (!supabase) {
      setError('Supabase not configured. Go to Settings to add your credentials.');
      return;
    }

    setUploading(true);
    setError('');
    try {
      const filename = `${Date.now()}-${file.name}`;
      const { data, error: uploadError } = await supabase.storage
        .from('progress_photos')
        .upload(filename, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('progress_photos')
        .getPublicUrl(filename);

      setPhotos([{ url: publicUrl, date: new Date().toLocaleDateString() }, ...photos]);
    } catch (err) {
      setError(err.message);
    }
    setUploading(false);
  };

  return (
    <div className="photo-gallery">
      <h2>Progress Photos</h2>
      
      <div className="upload-section">
        <button 
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading || !supabase}
        >
          {uploading ? 'Uploading...' : '📸 Upload Photo'}
        </button>
        <input 
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
          style={{ display: 'none' }}
        />
      </div>

      {error && <p className="error">{error}</p>}
      {!supabase && (
        <p style={{color: '#f7971e', marginBottom: '1rem'}}>
          📸 Photo upload disabled - configure Supabase in Settings to enable
        </p>
      )}

      <div className="photos-grid">
        {photos.length === 0 ? (
          <p>No photos yet. Upload your first progress photo!</p>
        ) : (
          photos.map((photo, i) => (
            <div key={i} className="photo-card">
              <img src={photo.url} alt={photo.date} />
              <p>{photo.date}</p>
            </div>
          ))
        )}
      </div>

      <style>{`
        .upload-section { margin-bottom: 2rem; }
        .upload-section button {
          background: #2f4a3c;
          color: #f7f4ee;
          padding: 1rem 2rem;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-weight: bold;
          font-size: 1rem;
        }
        .upload-section button:hover:not(:disabled) { background: #1a2815; }
        .upload-section button:disabled { opacity: 0.6; cursor: not-allowed; }
        .photos-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
          gap: 1rem;
        }
        .photo-card {
          border: 1px solid #e0e0e0;
          border-radius: 8px;
          overflow: hidden;
          text-align: center;
        }
        .photo-card img { width: 100%; height: 150px; object-fit: cover; }
        .photo-card p { padding: 0.5rem; font-size: 0.9rem; color: #666; }
      `}</style>
    </div>
  );
}
