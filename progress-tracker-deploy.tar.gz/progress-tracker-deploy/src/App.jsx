import { useState, useEffect } from 'react';
import Papa from 'papaparse';
import Charts from './components/Charts';
import PhotoGallery from './components/PhotoGallery';
import SheetConfig from './components/SheetConfig';
import './App.css';

export default function App() {
  const [sheetUrl, setSheetUrl] = useState(localStorage.getItem('sheetUrl') || '');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [supabaseConfig, setSupabaseConfig] = useState(
    JSON.parse(localStorage.getItem('supabaseConfig') || '{}')
  );
  const [tab, setTab] = useState('charts');

  const fetchData = async (url) => {
    if (!url) {
      setError('Please enter a Google Sheet CSV link');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const response = await fetch(url);
      const csv = await response.text();
      Papa.parse(csv, {
        header: true,
        complete: (results) => {
          const parsed = results.data
            .filter(r => r.Date && r.Weight)
            .map(r => ({
              date: r.Date,
              weight: parseFloat(r.Weight) || 0,
              bodyFat: parseFloat(r['Body Fat %']) || null,
              protein: parseFloat(r.Protein) || 0,
              carbs: parseFloat(r.Carbs) || 0,
              fat: parseFloat(r.Fat) || 0,
            }));
          setData(parsed);
          localStorage.setItem('sheetUrl', url);
        },
        error: (error) => setError(error.message),
      });
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  return (
    <div className="app">
      <header>
        <h1>💪 HawkFit Progress Tracker</h1>
        <p>Track weight, body fat, and performance metrics</p>
      </header>

      <SheetConfig 
        sheetUrl={sheetUrl} 
        onFetch={fetchData}
        loading={loading}
        error={error}
      />

      <nav className="tabs">
        <button 
          className={tab === 'charts' ? 'active' : ''} 
          onClick={() => setTab('charts')}
        >
          📊 Charts
        </button>
        <button 
          className={tab === 'photos' ? 'active' : ''}  
          onClick={() => setTab('photos')}
        >
          📸 Photos
        </button>
        <button 
          className={tab === 'settings' ? 'active' : ''} 
          onClick={() => setTab('settings')}
        >
          ⚙️ Settings
        </button>
      </nav>

      <main>
        {tab === 'charts' && <Charts data={data} loading={loading} />}
        {tab === 'photos' && (
          <PhotoGallery 
            supabaseConfig={supabaseConfig}
            onConfigChange={setSupabaseConfig}
          />
        )}
        {tab === 'settings' && (
          <Settings 
            supabaseConfig={supabaseConfig}
            onConfigChange={setSupabaseConfig}
          />
        )}
      </main>
    </div>
  );
}

function Settings({ supabaseConfig, onConfigChange }) {
  const [url, setUrl] = useState(supabaseConfig.url || '');
  const [key, setKey] = useState(supabaseConfig.key || '');

  const handleSave = () => {
    const config = { url, key };
    onConfigChange(config);
    localStorage.setItem('supabaseConfig', JSON.stringify(config));
    alert('Supabase config saved!');
  };

  return (
    <div className="settings">
      <h2>Supabase Configuration</h2>
      <p>To enable photo uploads, configure your Supabase project:</p>
      <div className="form-group">
        <label>Supabase URL</label>
        <input 
          type="text" 
          placeholder="https://xxx.supabase.co"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>
      <div className="form-group">
        <label>Anon Key</label>
        <input 
          type="password" 
          placeholder="eyJ..."
          value={key}
          onChange={(e) => setKey(e.target.value)}
        />
      </div>
      <button onClick={handleSave}>Save Config</button>
      <p style={{marginTop: '1rem', fontSize: '0.9rem', color: '#666'}}>
        Get these from your Supabase project settings → API
      </p>
    </div>
  );
}
